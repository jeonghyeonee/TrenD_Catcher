<?php
 
define('SCRIPTPATH','C:/Bitnami/wampstack-8.1.5-0/apache2/htdocs/');
 
define('DEBUG', true);

 
 
/******** DO NOT MODIFY ***********/
 
require_once('phpChart.php');     
 
/**********************************/
